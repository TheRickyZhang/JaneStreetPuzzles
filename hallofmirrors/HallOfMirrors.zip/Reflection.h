#ifndef HALLOFMIRRORS_REFLECTION_H
#define HALLOFMIRRORS_REFLECTION_H

#include <cmath>
#include <optional>
#include <stdexcept>
#include <iostream>
#include "Pixels.h"

enum struct MovementState { True, False, Nan };

std::ostream& operator<<(std::ostream& os, MovementState state);


//Retains line state over drawing iterations
struct LineDrawingState {
    int currentX;
    bool isDrawing;
    int cooldown;
    MovementState movingRight;
    MovementState movingUp;
    int lastY;
    LineDrawingState(int cx, int ly, MovementState mr, MovementState mu) : currentX(cx), isDrawing(true), cooldown(0), movingRight(mr), movingUp(mu), lastY(ly) {}
};

//Operates as normal xy-plane with +x->right, +y->down (flipped y due to image)
struct Line {
    double slope;
    double intercept; // Intercept at x = 0
    std::vector<int> operator()(int x, int lastY) const;
    Line(double _slope, Coord point) : slope(_slope), intercept(_slope == std::numeric_limits<double>::infinity() ? std::numeric_limits<double>::quiet_NaN() : point.y - _slope * point.x) {}
};

double calculateAngle(double slope, const LineDrawingState& s);
double getNewAngle(Line line, Pixel p, LineDrawingState s);
double getNewSlope(Line line, Pixel p, LineDrawingState s);

//Each call draws one shift in x value, updating parameters and variables depending on collision
void drawLineAndDetectCollision(std::vector<std::vector<Pixel>>& image, Line& line, const Pixel& lineColor,
                                const std::vector<PixelGroup>& groups, LineDrawingState& state);

#endif //HALLOFMIRRORS_REFLECTION_H
