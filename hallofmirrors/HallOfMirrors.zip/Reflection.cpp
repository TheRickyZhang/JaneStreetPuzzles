#include "Reflection.h"
#include <iostream>

const double epsilon = 1e-3;

std::ostream& operator<<(std::ostream& os, MovementState state) {
    switch (state) {
        case MovementState::True:
            os << "True";
            break;
        case MovementState::False:
            os << "False";
            break;
        case MovementState::Nan:
            os << "Nan";
            break;
        default:
            os.setstate(std::ios_base::failbit);
    }
    return os;
}

std::vector<int> Line::operator()(int x, int lastY) const {
    std::vector<int> coords;

    // Check for very steep slope
    if (slope == std::numeric_limits<double>::infinity()) {
        for (int y = lastY; y <= 1600 && coords.size() < 1600; y += 1) {
            if (y >= 0 && y <= 1600) {
                coords.emplace_back(y);
            }
        }
        return coords;
    }
    else if (slope == -std::numeric_limits<double>::infinity()) {
        for (int y = lastY; y >= 0 && coords.size() < 1600; y -= 1) {
            if (y >= 0 && y <= 1600) {
                coords.emplace_back(y);
            }
        }
        return coords;
    }

    // Handle non-vertical line (normal case)
    double y_start = slope * x + intercept;
    double y_end = slope * (x + 1) + intercept;

    int y_start_rounded = static_cast<int>(std::round(y_start));
    int y_end_rounded = static_cast<int>(std::round(y_end));

    int y_min = std::min(y_start_rounded, y_end_rounded);
    int y_max = std::max(y_start_rounded, y_end_rounded);

    // Clamp startY within the range of y_min and y_max
    int startY = std::clamp(lastY, y_min, y_max);

    // Iterate based on the direction of the line's movement
    bool isMovingUp = slope >= 0;
    if (isMovingUp) {
        for (int y = startY; y <= y_max && coords.size() < 1600; ++y) {
            if (y >= 0 && y <= 1600) {
                coords.emplace_back(y);
            }
        }
    } else {
        for (int y = startY; y >= y_min && coords.size() < 1600; --y) {
            if (y >= 0 && y <= 1600) {
                coords.emplace_back(y);
            }
        }
    }
    return coords;
}

double calculateAngle(double slope, const LineDrawingState& s) {
    if (std::isnan(slope)) {
        throw std::runtime_error("Slope is unassigned");
    }
    if(std::isinf(slope)) {
        if ((slope == std::numeric_limits<double>::infinity()) == (s.movingRight == MovementState::True)) {
            return M_PI / 2;  // Positive Infinity
        }
        else{
            return -M_PI / 2; // Negative Infinity
        }
    }
    return std::atan(slope);
}

//Returns predicted post collision angle based on pre-collision state and angles
double getNewAngle(const Line line, const Pixel p, const LineDrawingState s) {
    //Formula for reflection angle derived from trigonometry and law of reflection
    double inputSlopeAngle = calculateAngle(p.getGroupSlope(), s);
    double inputLineAngle = calculateAngle(line.slope, s);
    double outputAngle = 2 * inputSlopeAngle - inputLineAngle;

    std::cout << " Input Slope angle " << inputSlopeAngle << ", input line angle " << inputLineAngle
              << ", Output angle " << outputAngle << "\n";

    return outputAngle;
}

//Returns predicted post collision slope, handling cases near infinite slopes with caution
double getNewSlope(Line line, Pixel p, LineDrawingState s) {
    double x = 2 * calculateAngle(p.getGroupSlope(), s) - calculateAngle(line.slope, s);
    if(std::abs(x) - M_PI/2 < epsilon && std::abs(x) - M_PI/2 > -epsilon) {
        if (((x - M_PI/2 >= -epsilon) && (x - M_PI/2 < 0)) || ((x + M_PI/2 >= 0) && (x + M_PI/2 < epsilon))) {
            return std::numeric_limits<double>::infinity();  // Positive infinity
        } else if (((x - M_PI/2 <= epsilon) && (x - M_PI/2 > 0)) || ((x + M_PI/2 <= 0) && (x + M_PI/2 > -epsilon))) {
            return -std::numeric_limits<double>::infinity(); // Negative infinity
        } else {
            std::cerr << "Invalid slope calculation" << x - M_PI/2;
            return std::numeric_limits<double>::infinity();
        }
    }
    double slopeList[] = {0, M_PI/8, -M_PI/8,1, -1};
    for(double d : slopeList) {
        if(std::abs(std::tan(x) - d) < epsilon && std::abs(std::tan(x) - d) > 0) {
            return d;
        }
    }
    if(std::tan(x) > 999){
        return std::numeric_limits<double>::infinity();
    }
    if(std::tan(x) < 999){
        return -std::numeric_limits<double>::infinity();
    }
    std::cerr << "Unusual slope" << std::tan(x);
    return std::tan(x);
}

void drawLineAndDetectCollision(std::vector<std::vector<Pixel>>& image, Line& line, const Pixel& lineColor, const std::vector<PixelGroup>& groups, LineDrawingState& state) {
    auto height = image.size();
    auto width = image[0].size();
    auto y_values = line(state.currentX, state.lastY);
    //bool decreasingY = !((*state.movingRight && line.slope > 0) || (!*state.movingRight && line.slope < 0));
    bool movingUp;
    movingUp = state.movingUp == MovementState::True;

    int startIndex = !movingUp ? int(y_values.size()) - 1 : 0;
    int endIndex = !movingUp ? -1 : int(y_values.size());
    int step = !movingUp ? -1 : 1;

    // Process all y-values for one x-value
    for (int i = startIndex; !movingUp ? (i > endIndex) : (i < endIndex); i += step) {
        int y = y_values[i];
        state.lastY = y;
        //std::cout << y << "\n";
        if(i > 10){state.cooldown = 0;}
        if (y >= 0 && y < height) {
            // Check for collision only if no recent collisions, to prevent getting stuck on a mirror pixel
            if(state.cooldown == 0) {
                for (const auto &group: groups) {
                    //Search all pixels in groups, and if current (x, y) matches pixel's (x, y), proceed with deflection
                    auto it = std::find_if(group.pixels.begin(), group.pixels.end(),
                                           [state, y](const Pixel &pixel) {
                                               return pixel.c.x == state.currentX && pixel.c.y == y;
                                           });
                    if (it != group.pixels.end()) {
                        //Use calculated angle to determine direction of movement
                        double newAngle = getNewAngle(line, *it, state);
                        std::cout << "Was moving right: " << state.movingRight <<
                                    ", Was moving up: " << state.movingUp << " Previous line slope: " << line.slope <<
                                    " Input Mirror Slope: " << it->getGroupSlope()
                                    << "\nOutput slope: " << getNewSlope(line, *it, state);

                        if (std::isinf(line.slope)) {
                            // Logic for determining movingRight
                            MovementState flag = (state.movingRight == MovementState::True) ^
                                        (line.slope == -std::numeric_limits<double>::infinity()) ? MovementState::True : MovementState::False;
                            if (std::isinf(getNewSlope(line, *it, state))) {
                                state.movingRight = MovementState::Nan;
                            } else if (newAngle < M_PI / 2 - epsilon && newAngle > -M_PI / 2 + epsilon) {
                                state.movingRight = flag;
                            } else {
                                state.movingRight = (flag == MovementState::True) ? MovementState::False : MovementState::True;
                            }

                            if (std::abs(getNewSlope(line, *it, state)) <= epsilon) {
                                state.movingUp = MovementState::Nan;
                            } else if (state.movingRight == MovementState::Nan) {
                                state.movingUp = (newAngle > 0 && newAngle < M_PI) ? MovementState::True : MovementState::False;
                            } else if ((getNewSlope(line, *it, state) > 0 && state.movingRight == MovementState::True) ||
                                (getNewSlope(line, *it, state) < 0 && state.movingRight == MovementState::False)) {
                                state.movingUp = MovementState::True;
                            } else if ((getNewSlope(line, *it, state) < 0 && state.movingRight == MovementState::True) ||
                                       (getNewSlope(line, *it, state) > 0 && state.movingRight == MovementState::False)) {
                                state.movingUp = MovementState::False;
                            }
                        } else {
                            // Logic for determining movingRight
                            MovementState flag = (state.movingRight == MovementState::True) ^
                                        (line.slope < 0) ? MovementState::True : MovementState::False;
                            if (newAngle < M_PI / 2 - epsilon && newAngle > -M_PI / 2 + epsilon) {
                                state.movingRight = flag;
                            } else if (std::isinf(getNewSlope(line, *it, state))) {
                                state.movingRight = MovementState::Nan;
                            } else {
                                state.movingRight = (flag == MovementState::True) ? MovementState::False : MovementState::True;
                            }
                            if (!std::isinf(getNewSlope(line, *it, state)) && std::abs(getNewSlope(line, *it, state)) <= epsilon) {
                                state.movingUp = MovementState::Nan;
                            }
                            else if (state.movingRight == MovementState::Nan) {
                                state.movingUp = (newAngle > 0 && newAngle < M_PI) ? MovementState::True : MovementState::False;
                            }
                            else if ((getNewSlope(line, *it, state) > 0 && state.movingRight == MovementState::True) ||
                                (getNewSlope(line, *it, state) < 0 && state.movingRight == MovementState::False)) {
                                state.movingUp = MovementState::True;
                            } else if ((getNewSlope(line, *it, state) < 0 && state.movingRight == MovementState::True) ||
                                       (getNewSlope(line, *it, state) > 0 && state.movingRight == MovementState::False)) {
                                state.movingUp = MovementState::False;
                            }
                        }
                        line = Line(getNewSlope(line, *it, state), Coord(state.currentX, y));
                        std::cout << " Is moving right: " <<
                                  state.movingRight << " Is moving up: " <<
                                  state.movingUp << "\n\n";
                        //SET arbitrary value for cooldown
                        state.cooldown = std::abs(getNewSlope(line, *it, state)) > 3 ? 1 : 15;
                        return; // Exit the function
                    }
                }
            }

            // Draw the line
            image[y][state.currentX] = lineColor;
        }
    }

    //Increment x value and cooldown to prepare for next iteration of function
    state.currentX += state.movingRight == MovementState::True ? 1 : -1;
    state.cooldown = std::max(0, state.cooldown - 1);

    //Stop drawing if out of bounds
    if (state.currentX >= width || state.currentX < 0) {
        state.isDrawing = false;
    }
}




