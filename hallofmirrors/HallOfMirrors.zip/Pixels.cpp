#include "Pixels.h"
#include <iostream>

double Pixel::getGroupSlope() const {
    return (parentGroup->slope != std::numeric_limits<double>::quiet_NaN()) ? parentGroup->slope : std::numeric_limits<double>::quiet_NaN();
}

void PixelGroup::calculateSlope() {
    //Uses linear regression on points to find the slope, accounting for limits
    if (pixels.empty()) {
        slope = std::numeric_limits<double>::quiet_NaN();
        std::cout << "Calculated slope: NaN" << std::endl;
        return;
    }

    double sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    unsigned int n = pixels.size();
    for (const auto& p : pixels) {
        sumX += p.c.x;
        sumY += p.c.y;
        sumXY += p.c.x * p.c.y;
        sumX2 += p.c.x * p.c.x;
    }
    double denominator = n * sumX2 - sumX * sumX;
    if (denominator == 0) {
        // If all x-coordinates are same, vertical line.
        slope = std::numeric_limits<double>::infinity();
        std::cout << "Calculated slope: infinity" << std::endl;
        return;
    }

    slope = (n * sumXY - sumX * sumY) / denominator;
    double slopeValues[] = {0, 0.414213, 1, 2.414213, -0.414213, -1, -2.414213};
    for(double s : slopeValues) {
        if (slope > s - 0.1 && slope < s + 0.1) {
            slope = s;
            break;
        }
    }
    if(std::abs(slope) > 50) {
        slope = std::numeric_limits<double>::infinity();
    }
    std::cout << "Calculated slope: " << slope << std::endl;
}


void addPixelToGroup(int x, int y, int width, int height, const Pixel& targetColor, std::vector<std::vector<Pixel>>& pixelData, PixelGroup& group) {
    //Implements flood fill algorithm using stack calls to prevent stack overflow
    std::stack<Coord> stack;
    stack.emplace(x, y);

    while (!stack.empty()) {
        Coord current = stack.top();
        stack.pop();

        int cx = current.x;
        int cy = current.y;

        // Flood fill only proceeds if pixel is in bounds, not included in a group, and matches the target color
        if (cx < 0 || cy < 0 || cx >= width || cy >= height || pixelData[cy][cx].isIncluded || !(pixelData[cy][cx] == targetColor)) {
            continue;
        }

        //Sets parameters and adds pixel to a group
        pixelData[cy][cx].isIncluded = true;
        pixelData[cy][cx].parentGroup = &group;
        group.pixels.emplace_back(pixelData[cy][cx]);

        stack.emplace(cx + 1, cy);
        stack.emplace(cx - 1, cy);
        stack.emplace(cx, cy + 1);
        stack.emplace(cx, cy - 1);
    }
}